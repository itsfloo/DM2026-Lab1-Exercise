
from pathlib import Path
from typing import Any, Dict

import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
from langchain_core.tools import tool


def make_tools(session: Any) -> list:
    """Create dataset inspection and preprocessing tools."""

    @tool
    def tokenize_tool() -> Dict[str, Any]:
        """Tokenize each text document into lowercase word tokens.

        Returns token lists in document order and stores the result.
        """
        if session.dataframe is None or "text" not in session.dataframe.columns:
            raise ValueError("Load a dataset containing a 'text' column first.")

        import nltk
        from nltk.tokenize import word_tokenize

        try:
            nltk.data.find("tokenizers/punkt")
        except LookupError:
            nltk.download("punkt", quiet=True)
        try:
            nltk.data.find("tokenizers/punkt_tab")
        except LookupError:
            nltk.download("punkt_tab", quiet=True)

        tokens = [
            word_tokenize(str(text).lower()) if pd.notna(text) else []
            for text in session.dataframe["text"]
        ]
        session.artifacts["tokens"] = tokens

        rid = session.next_result_id("tokenize")
        summary = {
            "result_id": rid,
            "n_documents": len(tokens),
            "tokens": tokens,
        }
        session.store_result("tokenize_tool", {}, summary)
        return summary

    @tool
    def list_files_tool(subdirectory: str = ".") -> Dict[str, Any]:
        """List files and subdirectories under the project workspace.

        Args:
            subdirectory: Relative directory path to list.
        """
        root = Path.cwd().resolve()
        target = (root / subdirectory).resolve()
        if target != root and root not in target.parents:
            raise ValueError("Path must stay inside the project workspace.")
        if not target.is_dir():
            raise ValueError(f"Directory not found: {subdirectory}")

        files = sorted(p.name for p in target.iterdir() if p.is_file())
        directories = sorted(p.name for p in target.iterdir() if p.is_dir())

        rid = session.next_result_id("files")
        summary = {
            "result_id": rid,
            "subdirectory": subdirectory,
            "files": files,
            "directories": directories,
        }
        session.store_result(
            "list_files_tool", {"subdirectory": subdirectory}, summary
        )
        return summary

    @tool
    def inspect_data_tool() -> Dict[str, Any]:
        """Inspect the loaded dataset's dimensions, columns, types, and examples."""
        df = session.dataframe
        if df is None:
            raise ValueError("No dataset is loaded.")

        summary = {
            "result_id": session.next_result_id("inspect"),
            "n_rows": int(df.shape[0]),
            "n_columns": int(df.shape[1]),
            "columns": list(df.columns),
            "dtypes": {str(k): str(v) for k, v in df.dtypes.items()},
            "head": df.head(5).where(pd.notna(df.head(5)), None).to_dict("records"),
        }
        session.store_result("inspect_data_tool", {}, summary)
        return summary

    @tool
    def check_missing_tool() -> Dict[str, Any]:
        """Count missing values in each column and in the full dataset."""
        df = session.dataframe
        if df is None:
            raise ValueError("No dataset is loaded.")

        per_column = {str(k): int(v) for k, v in df.isna().sum().items()}
        summary = {
            "result_id": session.next_result_id("missing"),
            "missing_by_column": per_column,
            "total_missing": int(df.isna().sum().sum()),
            "rows_with_missing": int(df.isna().any(axis=1).sum()),
        }
        session.store_result("check_missing_tool", {}, summary)
        return summary

    @tool
    def check_duplicates_tool() -> Dict[str, Any]:
        """Count duplicate rows in the loaded dataset."""
        df = session.dataframe
        if df is None:
            raise ValueError("No dataset is loaded.")

        mask = df.duplicated()
        summary = {
            "result_id": session.next_result_id("duplicates"),
            "n_duplicates": int(mask.sum()),
            "duplicate_indices": [int(i) for i in df.index[mask].tolist()],
        }
        session.store_result("check_duplicates_tool", {}, summary)
        return summary

    @tool
    def sample_data_tool(n: int = 5, random_state: int = 42) -> Dict[str, Any]:
        """Return a reproducible random sample of dataset rows.

        Args:
            n: Number of rows to sample.
            random_state: Seed for reproducible sampling.
        """
        df = session.dataframe
        if df is None:
            raise ValueError("No dataset is loaded.")
        if not isinstance(n, int) or isinstance(n, bool) or n < 1:
            raise ValueError("n must be a positive integer.")
        if n > len(df):
            raise ValueError("n cannot exceed the number of dataset rows.")

        sampled = df.sample(n=n, random_state=random_state)
        records = sampled.astype(object).where(pd.notna(sampled), None).to_dict("records")
        summary = {
            "result_id": session.next_result_id("sample"),
            "n": n,
            "random_state": random_state,
            "indices": [int(i) for i in sampled.index.tolist()],
            "rows": records,
        }
        session.store_result(
            "sample_data_tool",
            {"n": n, "random_state": random_state},
            summary,
        )
        return summary

    @tool
    def describe_data_tool() -> Dict[str, Any]:
        """Summarize text character lengths and create a category boxplot."""
        df = session.dataframe
        if df is None or "text" not in df.columns:
            raise ValueError("Load a dataset containing a 'text' column first.")

        lengths = df["text"].fillna("").astype(str).str.len()
        desc = lengths.describe().to_dict()
        summary_stats = {
            str(k): round(float(v), 4) for k, v in desc.items()
        }
        summary = {
            "result_id": session.next_result_id("describe"),
            "character_length_summary": summary_stats,
            "character_lengths": [int(x) for x in lengths.tolist()],
        }

        if "category_name" in df.columns:
            categories = df["category_name"].fillna("Missing").astype(str)
            grouped = pd.DataFrame({
                "category_name": categories,
                "character_length": lengths,
            })
            per_category = {}
            for category, group in grouped.groupby("category_name", sort=True):
                stats = group["character_length"].describe().to_dict()
                per_category[str(category)] = {
                    str(k): round(float(v), 4) for k, v in stats.items()
                }
            summary["by_category"] = per_category

            fig, ax = plt.subplots(figsize=(7, 4))
            sns.boxplot(
                data=grouped,
                x="category_name",
                y="character_length",
                ax=ax,
            )
            ax.set_title("Text Length by Category")
            ax.set_xlabel("Category")
            ax.set_ylabel("Character Count")
            fig.tight_layout()
            session.pending_figure = fig

        session.store_result("describe_data_tool", {}, summary)
        return summary

    return [
        tokenize_tool,
        list_files_tool,
        inspect_data_tool,
        check_missing_tool,
        check_duplicates_tool,
        sample_data_tool,
        describe_data_tool,
    ]
