from typing import Any, Dict, List, Optional, Union

import matplotlib.pyplot as plt
import seaborn as sns
from langchain_core.tools import tool
from sklearn.feature_extraction.text import CountVectorizer


def make_tools(session: Any) -> list:
    """Create document-term matrix tools bound to a shared session."""

    @tool
    def build_dtm_tool(
        ngram_range: List[int] = [1, 1],
        max_features: Optional[int] = None,
        min_df: Union[int, float] = 1,
        max_df: Union[int, float] = 1.0,
    ) -> Dict[str, Any]:
        """Build a document-term matrix from the text column in the session."""

        if session.dataframe is None:
            raise ValueError("No dataset is loaded. Load a dataset first.")

        if "text" not in session.dataframe.columns:
            raise ValueError("The dataframe must contain a 'text' column.")

        if (
            not isinstance(ngram_range, (list, tuple))
            or len(ngram_range) != 2
            or not all(isinstance(x, int) and not isinstance(x, bool)
                       for x in ngram_range)
            or ngram_range[0] < 1
            or ngram_range[0] > ngram_range[1]
        ):
            raise ValueError("ngram_range must contain two valid positive integers.")

        vectorizer = CountVectorizer(
            ngram_range=tuple(ngram_range),
            max_features=max_features,
            min_df=min_df,
            max_df=max_df,
        )

        texts = session.dataframe["text"].fillna("").astype(str)
        matrix = vectorizer.fit_transform(texts)
        feature_names = vectorizer.get_feature_names_out().tolist()

        session.feature_matrix = matrix
        session.feature_names = feature_names

        if "category_name" in session.dataframe.columns:
            session.set_labels(session.dataframe["category_name"].values)
        elif "category" in session.dataframe.columns:
            session.set_labels(session.dataframe["category"].values)

        session.artifacts["count_vectorizer"] = vectorizer

        n_documents, n_terms = matrix.shape
        total_elements = n_documents * n_terms
        non_zero = int(matrix.nnz)
        sparsity_pct = (
            100.0 * (1.0 - non_zero / total_elements)
            if total_elements else 0.0
        )

        result_id = session.next_result_id("dtm")
        summary = {
            "result_id": result_id,
            "n_documents": int(n_documents),
            "n_terms": int(n_terms),
            "non_zero": non_zero,
            "total_elements": int(total_elements),
            "sparsity_pct": round(sparsity_pct, 4),
            "feature_names": feature_names,
        }

        session.store_result(
            "build_dtm_tool",
            {
                "ngram_range": list(ngram_range),
                "max_features": max_features,
                "min_df": min_df,
                "max_df": max_df,
            },
            summary,
        )
        return summary


    @tool
    def term_frequency_tool() -> Dict[str, Any]:
        """Calculate total term frequencies from the document-term matrix."""
        if session.feature_matrix is None or session.feature_names is None:
            raise ValueError("Build the document-term matrix first.")

        totals = session.feature_matrix.sum(axis=0).A1
        frequencies = [
            {"term": term, "frequency": int(freq)}
            for term, freq in zip(session.feature_names, totals)
        ]

        result_id = session.next_result_id("term_frequency")
        summary = {
            "result_id": result_id,
            "n_terms": len(frequencies),
            "term_frequencies": frequencies,
        }
        session.store_result("term_frequency_tool", {}, summary)
        return summary

    @tool
    def dtm_heatmap_tool(
        n_terms: int = 20,
        n_documents: int = 20,
    ) -> Dict[str, Any]:
        """Create a heatmap for a subset of the document-term matrix."""
        if session.feature_matrix is None or session.feature_names is None:
            raise ValueError("Build the document-term matrix first.")
        if not isinstance(n_terms, int) or isinstance(n_terms, bool) or n_terms < 1:
            raise ValueError("n_terms must be a positive integer.")
        if not isinstance(n_documents, int) or isinstance(n_documents, bool) or n_documents < 1:
            raise ValueError("n_documents must be a positive integer.")

        matrix = session.feature_matrix[:n_documents, :n_terms].toarray()
        terms = session.feature_names[:n_terms]
        doc_count, term_count = matrix.shape

        fig, ax = plt.subplots(figsize=(
            max(6, term_count * 0.8),
            max(3, doc_count * 0.45),
        ))
        sns.heatmap(
            matrix,
            annot=True,
            fmt="g",
            cmap="YlGnBu",
            xticklabels=terms,
            yticklabels=[f"Doc {i}" for i in range(doc_count)],
            ax=ax,
        )
        ax.set_title("Document-Term Matrix Heatmap")
        ax.set_xlabel("Terms")
        ax.set_ylabel("Documents")
        fig.tight_layout()
        session.pending_figure = fig

        result_id = session.next_result_id("dtm_heatmap")
        summary = {
            "result_id": result_id,
            "n_documents": int(doc_count),
            "n_terms": int(term_count),
            "feature_names": terms,
            "matrix": matrix.tolist(),
        }
        session.store_result(
            "dtm_heatmap_tool",
            {"n_terms": n_terms, "n_documents": n_documents},
            summary,
        )
        return summary

    return [build_dtm_tool, term_frequency_tool, dtm_heatmap_tool]

