
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from langchain_core.tools import tool


def make_tools(session):

    @tool
    def cosine_similarity_tool(doc1: int, doc2: int) -> dict:
        """Calculate cosine similarity between two document vectors in the DTM."""
        if session.feature_matrix is None:
            return {"error": "Build the document-term matrix first."}

        X = session.feature_matrix
        n_docs = X.shape[0]

        if not (0 <= doc1 < n_docs and 0 <= doc2 < n_docs):
            return {"error": f"Document indices must be between 0 and {n_docs - 1}."}

        a = X[doc1].toarray().ravel()
        b = X[doc2].toarray().ravel()

        norm_a = np.linalg.norm(a)
        norm_b = np.linalg.norm(b)

        if norm_a == 0 or norm_b == 0:
            similarity = 0.0
        else:
            similarity = float(np.dot(a, b) / (norm_a * norm_b))

        result_id = session.next_result_id("cosine_similarity")
        result = {
            "result_id": result_id,
            "doc1": doc1,
            "doc2": doc2,
            "similarity": similarity,
        }

        session.store_result(
            "cosine_similarity_tool",
            {"doc1": doc1, "doc2": doc2},
            result,
        )

        return result

    @tool
    def feature_correlation_matrix_tool() -> dict:
        """Calculate feature correlations and display a correlation heatmap."""
        if session.feature_matrix is None:
            return {"error": "Build the document-term matrix first."}

        X = session.feature_matrix.toarray()
        feature_names = list(session.feature_names)

        df = pd.DataFrame(X, columns=feature_names)

        # Sort features by descending variance.
        variances = df.var(axis=0).sort_values(ascending=False)
        ordered_features = list(variances.index)
        corr = df[ordered_features].corr()

        fig, ax = plt.subplots(figsize=(8, 6))
        sns.heatmap(
            corr,
            annot=True,
            fmt=".2f",
            cmap="coolwarm",
            vmin=-1,
            vmax=1,
            center=0,
            ax=ax,
        )
        ax.set_title("Feature Correlation Matrix")
        fig.tight_layout()

        session.pending_figure = fig

        result_id = session.next_result_id("feature_correlation")
        result = {
            "result_id": result_id,
            "features": ordered_features,
            "correlation_matrix": corr.values.tolist(),
        }

        session.store_result(
            "feature_correlation_matrix_tool",
            {},
            result,
            full_report=corr,
        )

        return result

    return [cosine_similarity_tool, feature_correlation_matrix_tool]
