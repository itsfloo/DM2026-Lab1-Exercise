
from typing import Any, Dict
import numpy as np
import pandas as pd
from scipy.stats import pearsonr, spearmanr
from langchain_core.tools import tool


def make_tools(session: Any) -> list:
    """Create feature-filtering tools bound to a session."""

    def get_target_labels():
        df = session.dataframe

        if df is None:
            raise ValueError("Load a dataset first.")

        if "category_name" in df.columns:
            return df["category_name"].to_numpy()
        if "category" in df.columns:
            return df["category"].to_numpy()

        raise ValueError(
            "Dataframe must contain 'category_name' or 'category'."
        )

    def check_dtm():
        if session.feature_matrix is None or session.feature_names is None:
            raise ValueError("Build the document-term matrix first.")

        matrix = session.feature_matrix
        names = list(session.feature_names)

        if matrix.shape[1] != len(names):
            raise ValueError("Feature names do not match the matrix.")

        return matrix, names

    @tool
    def variance_filter_tool(threshold: float = 0.15) -> Dict[str, Any]:
        """Filter terms by their variance across documents.

        Args:
            threshold: Minimum variance required to keep a term.
        """
        if threshold < 0:
            raise ValueError("threshold must be non-negative.")

        matrix, names = check_dtm()
        variances = np.var(matrix.toarray(), axis=0, ddof=0)

        report = pd.DataFrame({
            "feature": names,
            "variance": variances,
        }).sort_values("variance", ascending=False).reset_index(drop=True)

        kept = report.loc[
            report["variance"] >= threshold, "feature"
        ].tolist()
        removed = report.loc[
            report["variance"] < threshold, "feature"
        ].tolist()

        result_id = session.next_result_id("variance_filter")
        summary = {
            "result_id": result_id,
            "threshold": float(threshold),
            "n_features": len(names),
            "n_kept": len(kept),
            "n_removed": len(removed),
            "kept_features": kept,
            "removed_features": removed,
            "variances": {
                str(row["feature"]): float(row["variance"])
                for _, row in report.iterrows()
            },
        }

        session.store_result(
            "variance_filter_tool",
            {"threshold": threshold},
            summary,
            full_report=report,
        )
        return summary

    def correlation_filter(target_class: str, method: str):
        """Calculate feature correlation with a one-vs-rest target label."""
        matrix, names = check_dtm()
        labels = get_target_labels()

        if len(labels) != matrix.shape[0]:
            raise ValueError("Target labels and document-term rows differ.")

        target = (labels == target_class).astype(int)

        if len(np.unique(target)) < 2:
            raise ValueError(
                f"Target class {target_class!r} must exist alongside "
                "at least one other class."
            )

        counts = matrix.toarray()
        correlations = []

        for index, name in enumerate(names):
            values = counts[:, index]

            if np.std(values) == 0:
                coefficient = 0.0
            elif method == "pearson":
                coefficient = float(pearsonr(values, target).statistic)
            else:
                result = spearmanr(values, target)
                coefficient = (
                    float(result.statistic)
                    if np.isfinite(result.statistic)
                    else 0.0
                )

            correlations.append({
                "feature": str(name),
                f"{method}_r": coefficient,
            })

        report = pd.DataFrame(correlations).sort_values(
            f"{method}_r", ascending=False
        ).reset_index(drop=True)

        result_id = session.next_result_id(f"{method}_filter")
        summary = {
            "result_id": result_id,
            "target_class": target_class,
            "n_features": len(names),
            "correlations": {
                str(row["feature"]): float(row[f"{method}_r"])
                for _, row in report.iterrows()
            },
        }

        tool_name = f"{method}_filter_tool"
        session.store_result(
            tool_name,
            {"target_class": target_class},
            summary,
            full_report=report,
        )
        return summary

    @tool
    def pearson_filter_tool(target_class: str) -> Dict[str, Any]:
        """Calculate Pearson correlation between term counts and a target class.

        Args:
            target_class: Category treated as positive; all other categories
                are treated as negative.
        """
        return correlation_filter(target_class, "pearson")

    @tool
    def spearman_filter_tool(target_class: str) -> Dict[str, Any]:
        """Calculate Spearman correlation between term counts and a target class.

        Args:
            target_class: Category treated as positive; all other categories
                are treated as negative.
        """
        return correlation_filter(target_class, "spearman")

    return [
        variance_filter_tool,
        pearson_filter_tool,
        spearman_filter_tool,
    ]
