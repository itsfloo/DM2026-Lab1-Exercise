
from typing import Any, Dict
import tempfile
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer, TfidfTransformer
from langchain_core.tools import tool


def make_tools(session: Any) -> list:
    """Create frequent-pattern mining tools bound to a session."""

    @tool
    def mine_patterns_tool(
        category_name: str,
        filtering_method: str,
        algorithm: str = "fpgrowth",
        min_sup: int = 1,
        k: int = 5,
    ) -> Dict[str, Any]:
        """Mine frequent word patterns from documents in one category.

        Builds a category-specific document-term matrix, filters its terms,
        converts the remaining terms into transactions, and mines patterns.

        Args:
            category_name: Category to mine.
            filtering_method: Vocabulary filter: variance, tfidf, or term_frequency.
            algorithm: Mining algorithm: fpgrowth, topk, or maxfpgrowth.
            min_sup: Minimum support for fpgrowth and maxfpgrowth.
            k: Number of top patterns for topk.
        """
        if filtering_method not in {
            "variance", "tfidf", "term_frequency"
        }:
            raise ValueError(
                "filtering_method must be variance, tfidf, or term_frequency."
            )

        if algorithm not in {"fpgrowth", "topk", "maxfpgrowth"}:
            raise ValueError(
                "algorithm must be fpgrowth, topk, or maxfpgrowth."
            )

        if algorithm != "topk" and min_sup < 1:
            raise ValueError("min_sup must be at least 1.")

        if algorithm == "topk" and k < 1:
            raise ValueError("k must be at least 1.")

        df = session.dataframe
        if df is None:
            raise ValueError("Load a dataset first.")

        if "text" not in df.columns:
            raise ValueError("The dataframe must contain a 'text' column.")

        label_col = (
            "category_name"
            if "category_name" in df.columns
            else "category"
            if "category" in df.columns
            else None
        )
        if label_col is None:
            raise ValueError(
                "The dataframe must contain 'category_name' or 'category'."
            )

        category_df = df.loc[df[label_col] == category_name].copy()
        if category_df.empty:
            raise ValueError(
                f"Category {category_name!r} was not found."
            )

        texts = category_df["text"].fillna("").astype(str).tolist()

        vectorizer = CountVectorizer(stop_words="english")
        try:
            matrix = vectorizer.fit_transform(texts)
        except ValueError as exc:
            if "empty vocabulary" not in str(exc).lower():
                raise
            matrix = None

        result_id = session.next_result_id("patterns")
        artifact_key = (
            f"patterns_{category_name}_{filtering_method}_{algorithm}"
        )

        def finish(patterns, note=None, vocabulary=None):
            summary = {
                "result_id": result_id,
                "category_name": category_name,
                "filtering_method": filtering_method,
                "algorithm": algorithm,
                "patterns": patterns,
                "n_patterns": len(patterns),
                "vocabulary": vocabulary or [],
            }
            if note:
                summary["note"] = note

            session.artifacts[artifact_key] = patterns
            session.store_result(
                "mine_patterns_tool",
                {
                    "category_name": category_name,
                    "filtering_method": filtering_method,
                    "algorithm": algorithm,
                    "min_sup": min_sup,
                    "k": k,
                },
                summary,
            )
            return summary

        if matrix is None or matrix.shape[1] == 0:
            return finish(
                [],
                note="no terms available after stopword removal",
            )

        terms = np.asarray(vectorizer.get_feature_names_out())
        counts = matrix.toarray()

        if filtering_method == "variance":
            scores = np.var(counts, axis=0)
            lower, upper = np.percentile(scores, [5, 95])
            keep = (scores >= lower) & (scores <= upper)

        elif filtering_method == "term_frequency":
            scores = counts.sum(axis=0)
            lower, upper = np.percentile(scores, [5, 95])
            keep = (scores >= lower) & (scores <= upper)

        else:
            tfidf = TfidfTransformer().fit_transform(matrix)
            scores = np.asarray(tfidf.mean(axis=0)).ravel()
            cutoff = np.percentile(scores, 20)
            keep = scores >= cutoff

        kept_terms = terms[keep].tolist()
        filtered_counts = counts[:, keep]

        if not kept_terms:
            return finish(
                [],
                note="no terms survived filtering",
                vocabulary=[],
            )

        # Convert the filtered binary presence matrix into transactions.
        transaction_df = pd.DataFrame(
            (filtered_counts >= 1).astype(int),
            columns=kept_terms,
        )

        with tempfile.TemporaryDirectory() as temp_dir:
            db_path = str(Path(temp_dir) / "transactions.txt")

            # Use PAMI's dataframe-to-transaction converter.
            from PAMI.extras.convert import DF2DB

            converter = DF2DB.DF2DB(
                transaction_df, DFtype="dense"
            )
            converter.convert2TransactionalDatabase(db_path, ">", 0)

            if algorithm == "fpgrowth":
                from PAMI.frequentPattern.basic import FPGrowth

                miner = FPGrowth.FPGrowth(db_path, min_sup)

            elif algorithm == "topk":
                from PAMI.frequentPattern.topk import FAE

                miner = FAE.FAE(db_path, k)

            else:
                from PAMI.frequentPattern.maximal import MaxFPGrowth

                miner = MaxFPGrowth.MaxFPGrowth(db_path, min_sup)

            miner.startMine()
            raw_patterns = miner.getPatterns()

        patterns = []
        for raw_pattern, support in raw_patterns.items():
            if isinstance(raw_pattern, (tuple, list, set)):
                items = [str(item) for item in raw_pattern]
            else:
                items = [
                    item.strip()
                    for item in str(raw_pattern).split("\t")
                    if item.strip()
                ]

            patterns.append({
                "items": items,
                "support": int(support),
            })

        patterns.sort(
            key=lambda item: (
                -item["support"],
                item["items"],
            )
        )

        return finish(
            patterns,
            note=(
                "no patterns found by the selected algorithm"
                if not patterns else None
            ),
            vocabulary=kept_terms,
        )

    return [mine_patterns_tool]
