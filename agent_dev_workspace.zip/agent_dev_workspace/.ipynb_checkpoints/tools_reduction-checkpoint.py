import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from langchain_core.tools import tool
from sklearn.decomposition import PCA
from sklearn.manifold import TSNE


def make_tools(session):
    @tool
    def reduce_dimensions_tool(
        method: str = "pca",
        random_state: int = 42,
        perplexity: float = 30.0,
        n_neighbors: int = 15,
    ) -> dict:
        """Reduce the document-term matrix to two dimensions and plot the results.

        Args:
            method: Dimensionality reduction method: pca, tsne, or umap.
            random_state: Random seed for reproducibility.
            perplexity: Perplexity parameter used by t-SNE.
            n_neighbors: Number of neighbors used by UMAP.
        """
        method = method.lower().strip()

        if method not in {"pca", "tsne", "umap"}:
            raise ValueError("method must be 'pca', 'tsne', or 'umap'")

        if session.feature_matrix is None:
            raise ValueError(
                "Feature matrix is missing. Run build_dtm_tool first."
            )

        X = session.feature_matrix.toarray()
        n_samples = X.shape[0]

        if n_samples < 2:
            raise ValueError("At least two documents are required.")

        if method == "pca":
            reducer = PCA(n_components=2, random_state=random_state)
            coordinates = reducer.fit_transform(X)
            explained_variance_ratio = (
                reducer.explained_variance_ratio_.tolist()
            )

        elif method == "tsne":
            actual_perplexity = min(perplexity, n_samples - 1)
            reducer = TSNE(
                n_components=2,
                perplexity=actual_perplexity,
                random_state=random_state,
                init="pca",
                learning_rate="auto",
            )
            coordinates = reducer.fit_transform(X)
            explained_variance_ratio = None

        else:
            try:
                import umap
            except ImportError as exc:
                raise ImportError(
                    "UMAP is not installed. Install it with: pip install umap-learn"
                ) from exc

            reducer = umap.UMAP(
                n_components=2,
                n_neighbors=min(n_neighbors, n_samples - 1),
                random_state=random_state,
            )
            coordinates = reducer.fit_transform(X)
            explained_variance_ratio = None

        df = session.dataframe
        if "category_name" in df.columns:
            categories = df["category_name"].astype(str).tolist()
        elif "category" in df.columns:
            categories = df["category"].astype(str).tolist()
        else:
            categories = ["All documents"] * n_samples

        if len(categories) != n_samples:
            categories = ["All documents"] * n_samples

        result_df = pd.DataFrame({
            "Dimension 1": coordinates[:, 0],
            "Dimension 2": coordinates[:, 1],
            "Category": categories,
        })

        fig, ax = plt.subplots(figsize=(9, 6))
        sns.scatterplot(
            data=result_df,
            x="Dimension 1",
            y="Dimension 2",
            hue="Category",
            palette="tab10",
            s=70,
            ax=ax,
        )
        ax.set_title(f"{method.upper()} Dimensionality Reduction")
        ax.set_xlabel("Dimension 1")
        ax.set_ylabel("Dimension 2")
        ax.legend(title="Category", bbox_to_anchor=(1.05, 1), loc="upper left")
        fig.tight_layout()

        session.pending_figure = fig

        result = {
            "method": method,
            "coordinates": coordinates.tolist(),
            "explained_variance_ratio": explained_variance_ratio,
            "categories": categories,
        }
        result_id = session.next_result_id("reduce_dimensions")
        result["result_id"] = result_id

        session.store_result(
            "reduce_dimensions_tool",
            {
                "method": method,
                "random_state": random_state,
                "perplexity": perplexity,
                "n_neighbors": n_neighbors,
            },
            result,
            full_report=result_df,
        )

        return result

    @tool
    def binarize_labels_tool() -> dict:
        """Convert the current category labels into one-hot binary columns."""
        labels = getattr(session, "labels", None)

        if labels is None:
            return {"error": "No labels available. Build the DTM first."}

        labels = pd.Series(labels).fillna("unknown").astype(str)
        categories = sorted(labels.unique())

        binary = pd.get_dummies(labels).reindex(
            columns=categories,
            fill_value=0,
        ).astype(int)

        binary.index = range(len(binary))

        result_id = session.next_result_id("binarize_labels")

        result = {
            "result_id": result_id,
            "categories": categories,
            "shape": list(binary.shape),
            "labels": binary.values.tolist(),
            "columns": categories,
        }

        session.store_result(
            "binarize_labels_tool",
            {},
            result,
            full_report=binary,
        )

        return result

    return [reduce_dimensions_tool, binarize_labels_tool]